use testdb;
CREATE TABLE Users (
    userId int NOT NULL AUTO_INCREMENT,
    userName varchar(255) NOT NULL,
    password varchar(255),
    role varchar(255),
    PRIMARY KEY (userId)
);
CREATE TABLE Tickets (
    ticketId varchar(255) NOT NULL,
    title varchar(255) NOT NULL,
    description varchar(255),
    assignedId int,
    assignedName varchar(255),
    status varchar(255),
    priority varchar(255),
    comments text,
    createdBy varchar(255),
    createdDate datetime,
    updatedBy varchar(255),
    updatedDate datetime,
    PRIMARY KEY (ticketId)
);
SELECT * FROM testdb.Tickets;
INSERT INTO Users (userName,password,role)
VALUES ('Admin','Admin','ADMIN');
INSERT INTO Users (userName,password,role)
VALUES ('Super-User','SuperUser','ADMIN');
INSERT INTO Users (userName,password,role)
VALUES ('User1','User1','USER');
INSERT INTO Users (userName,password,role)
VALUES ('User2','User2','USER');
INSERT INTO Users (userName,password,role)
VALUES ('User3','User3','USER');
INSERT INTO Users (userName,password,role)
VALUES ('User4','User4','USER');
INSERT INTO Users (userName,password,role)
VALUES ('User5','User5','USER');
INSERT INTO Users (userName,password,role)
VALUES ('User6','User6','USER');
INSERT INTO Users (userName,password,role)
VALUES ('User7','User7','USER');