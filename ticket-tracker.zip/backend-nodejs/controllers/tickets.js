var db = require("../db_setup/db");
var config = require("../db_setup/config");
var jwt = require('jsonwebtoken');
const { nanoid } = require('nanoid')

exports.login =  (req, res) => {
    var data = req.body;
    if (!data) throw new Error("Invalid Param");
    db.executeSql(`SELECT userId,userName,role FROM Users Where userName = '${data.username}' AND password = '${data.password}'`, (data, err) => {
        if (err) {
            res.status(500).json(err);
        }
        else {
            console.log(data)
            if (data.length) {
                const user = data[0];
                var token = jwt.sign({ id: user.id }, config.secret, {
                    expiresIn: 86400 // expires in 24 hours
                });
                res.status(200).send({
                    auth: true,
                    accessToken: token,
                    userId: user.userId,
                    userName: user.userName,
                    role: user.role
                });
                // res.json(data);
            } else {
                return res.status(401).send({ auth: false, token: null });
            }
        }
    });
};

exports.getUsers = (req, res) => {
    db.executeSql("SELECT userId,userName FROM Users", (data, err) => {
        if (err) {
            res.status(500).json({ "msg": err });
        }
        else {
            res.json(data);
        }
    });
};

exports.getTickets = (req, res) => {
    db.executeSql("SELECT * FROM Tickets", (data, err) => {
        if (err) {
            res.status(500).json({ "msg": err });
        }
        else {
            res.json(data);
        }
    });
};

exports.getMyTickets = (req, res, userId) => {
    db.executeSql(`SELECT * FROM Tickets Where assignedId='${userId}'`, (data, err) => {
        if (err) {
            res.status(500).json({ "msg": err });
        }
        else {
            res.json(data);
        }
    });
};

exports.add = (req, res) => {
    try {
        var data = req.body;
        if (data) {//add more validations if necessary
            console.log(data);
            const created = new Date(data.createdDate);
            const mySQLCDateString = created.toJSON().slice(0, 19).replace('T', ' ');
            const updated = new Date(data.updatedDate);
            const mySQLUDateString = updated.toJSON().slice(0, 19).replace('T', ' ');
            var sql = `INSERT INTO Tickets (
                ticketId,title,description,assignedId,assignedName,status,
                priority,comments,createdBy,createdDate,updatedBy,updatedDate
                ) VALUES ('${'INC' + nanoid(10)}','${data.title}','${data.description}','${data.assignedId}','${data.assignedName}','${data.status}',
                '${data.priority}','${data.comments}','${data.createdBy}','${mySQLCDateString}','${data.updatedBy}','${mySQLUDateString}')`;
            console.log(sql);
            db.executeSql(sql, (data, err) => {
                if (err) {
                    res.status(500).json({ "msg": err });
                }
                else {
                    res.status(200).json({ "msg": "Ticket Added Successfully" });//or res.status(200).send('OK')
                }
            });
        }
        else {
            throw new Error("Input not valid");
        }
    }
    catch (ex) {
        res.status(500).json({ msg: ex.message });
    }
};

exports.update = (req, res, ticketId) => {
    try {
        var data = req.body;
        if (data) {
            if (!ticketId) throw new Error("TicketId not provided");
            const created = new Date(data.createdDate);
            const mySQLCDateString = created.toJSON().slice(0, 19).replace('T', ' ');
            const updated = new Date(data.updatedDate);
            const mySQLUDateString = updated.toJSON().slice(0, 19).replace('T', ' ');
            var sql = `UPDATE Tickets SET title='${data.title}',description='${data.description}',assignedId='${data.assignedId}',assignedName='${data.assignedName}',status='${data.status}',
            priority='${data.priority}',comments='${data.comments}',createdBy='${data.createdBy}',createdDate='${mySQLCDateString}',updatedBy='${data.updatedBy}',updatedDate='${mySQLUDateString}' WHERE ticketId = '${ticketId}'`;

            db.executeSql(sql, (data, err) => {
                if (err) {
                    res.status(500).json({ "msg": err });
                }
                else {
                    res.status(200).json({ "msg": "Ticket Updated Successfully" });
                }
            });
        }
        else {
            throw new Error("Input not valid");
        }
    }
    catch (ex) {
        res.status(500).json({ msg: ex.message });
    }
};

exports.delete = (req, res, ticketId) => {
    try {
        if (!ticketId) throw new Error("TicketId not provided");
        var sql = `DELETE FROM Tickets WHERE ticketId = '${ticketId}'`;

        db.executeSql(sql, (data, err) => {
            if (err) {
                res.status(500).json({ "msg": err });
            }
            else {
                res.status(200).json({ "msg": "Ticket Deleted Successfully" });
            }
        });
    }
    catch (ex) {
        res.status(500).json({ msg: ex.message });
    }
};