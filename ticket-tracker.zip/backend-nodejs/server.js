const sqlDb = require('mssql')
var express = require('express');
var bodyParser = require('body-parser');
var cors = require("cors");
const authJwt = require('./verifyJwtToken');
var controller = require("./controllers/tickets");
const settings = require("./db_setup/db-config");

var app = express();
app.use(cors());
var router = express.Router();
//-->following two line needed for POST/PUT etc.
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
router.get('/', (req, res) => {
   res.json({ msg: "Use '/api/tickets' to fetch all tickets" });
});
//-->method 1
router.post('/api/login', controller.login);
router.get('/api/getUsers', [authJwt.verifyToken], (req, res) => {
   controller.getUsers(req, res);
});
router.get('/api/tickets', [authJwt.verifyToken],(req, res) => {
   controller.getTickets(req, res);
});
router.get('/api/mytickets/:userId', [authJwt.verifyToken],(req, res) => {
   controller.getMyTickets(req, res, req.params.userId);
});
router.post('/api/tickets', [authJwt.verifyToken],(req, res) => {
   controller.add(req, res);
});
router.put('/api/tickets/:ticketId', [authJwt.verifyToken],(req, res) => {
   controller.update(req, res, req.params.ticketId);
});
router.delete('/api/tickets/:ticketId',[authJwt.verifyToken], (req, res) => {
   controller.delete(req, res, req.params.ticketId);
});
app.use('/', router);
app.listen(settings.webPort, () => {
   console.log("Started listening at: " + settings.webPort);
})
