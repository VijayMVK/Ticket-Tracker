var mysql = require('mysql2');
const env = require('./env.js');
var connection = mysql.createConnection({
    host: env.host,
    user: env.username,
    password: env.password,
    database: env.database,
});

exports.executeSql = function (sql, callback) {
    //intentional blocking delay
    var seconds = 3; //3 second delay
    var waitTill = new Date(new Date().getTime() + seconds * 1000);
    while (waitTill > new Date()) { };
    console.log(sql);
    connection.query(sql, function (err, results, fields) {
        if (err) callback(null, err);
        else callback(results);
    }
    );
};