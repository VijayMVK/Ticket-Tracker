const env = {
  database: 'testdb',
  username: 'root',
  password: 'root',
  host: 'localhost',
  dialect: 'mysql'
};

module.exports = env;
