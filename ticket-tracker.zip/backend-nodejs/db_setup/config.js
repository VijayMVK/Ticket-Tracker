module.exports = {
  'secret': 'ticket-super-secret-key',
  roles: ['USER', 'ADMIN']
};