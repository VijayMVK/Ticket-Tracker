import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { TableComponent } from './shared/component/table/table.component';
import { PageNotFoundComponent } from './shared/component/page-not-found/page-not-found.component';
import { AddDialogComponent } from './shared/component/table/dialogs/add/add.dialog.component';
import { EditDialogComponent } from './shared/component/table/dialogs/edit/edit.dialog.component';
import { DeleteDialogComponent } from './shared/component/table/dialogs/delete/delete.dialog.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CommonService } from './shared/service/common.service';
import { httpInterceptorProviders } from './shared/service/auth-interceptor';
import { AuthGuard } from './shared/service/auth.service';
import { AdminGuard } from './shared/service/admin.service';
import { LoginGuard } from './shared/service/login.service';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { MyTicketsComponent } from './my-tickets/my-tickets.component';
import { UserManagementComponent } from './user-management/user-management.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    MyTicketsComponent,
    UserManagementComponent,
    AddDialogComponent,
    EditDialogComponent,
    DeleteDialogComponent,
    TableComponent,
    PageNotFoundComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    MatDialogModule,
    MatButtonModule,
    MatInputModule,
    MatIconModule,
    MatSortModule,
    MatTableModule,
    MatToolbarModule,
    MatPaginatorModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatSnackBarModule
  ],
  entryComponents: [
    AddDialogComponent,
    EditDialogComponent,
    DeleteDialogComponent
  ],
  providers: [CommonService, AuthGuard, AdminGuard,LoginGuard,httpInterceptorProviders],
  bootstrap: [AppComponent]
})
export class AppModule { }
