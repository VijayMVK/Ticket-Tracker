export interface EmployeeModel {
    email: string;
    id: number;
    name: string;
    phone: string;
    salary: number;
    username: string;
}
export interface UserModel {
    userId: number;
    userName: string;
    role: string;
}
export class DropDownModel {
    code: string;
    value: string;
}
export class UserDropDownModel {
    userId: string;
    userName: string;
}

export class InputModel {
    apiUrl: string;
    isDisable: boolean;
}

export class JwtResponse {
    accessToken: string;
    userId: string;
    userName: string;
    role: string;
}

export class AuthLoginInfo {
    username: string;
    password: string;

    constructor(username: string, password: string) {
        this.username = username;
        this.password = password;
    }
}


export class TicketModel {
    ticketId: string;
    title: string;
    description: string;
    assignedId: string;
    assignedName: string;
    status: string;
    priority: string;
    comments: string = '';
    createdBy: string;
    updatedBy: string;
    createdDate: string;
    updatedDate: string;
}
