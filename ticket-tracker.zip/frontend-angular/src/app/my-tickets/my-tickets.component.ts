import { Component, OnInit } from '@angular/core';
import { CommonService } from '../shared/service/common.service';

@Component({
  selector: 'app-my-tickets',
  templateUrl: './my-tickets.component.html',
  styleUrls: ['./my-tickets.component.css']
})
export class MyTicketsComponent implements OnInit {
  constructor(public commonService: CommonService) { }
  ngOnInit() {
    this.commonService.ticketApi = `mytickets/${this.commonService.userInfo.userId}`;
    this.commonService.isDisable = true;
  }

}

