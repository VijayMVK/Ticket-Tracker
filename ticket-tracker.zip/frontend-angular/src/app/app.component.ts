import { Component, OnInit } from '@angular/core';
import { CommonService } from './shared/service/common.service';
import { TokenStorageService } from './shared/service/token-storage.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  constructor(public commonService: CommonService, public tokenStorageService: TokenStorageService, private router: Router) { }
  ngOnInit() { }
  logout() {
    this.commonService.ticketApi = '';
    this.commonService.userInfo = undefined;
    this.commonService.userList = [];
    this.commonService.ticketId = '';
    this.tokenStorageService.signOut();
  }
}
