import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router, CanActivateChild } from '@angular/router';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { CommonService } from './common.service'
@Injectable()
export class AdminGuard implements CanActivate {
    constructor(private router: Router, private commonService: CommonService) { }
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
        return this.commonService.isAdmin()
            .then((authenticated: boolean) => {
                if (authenticated) {
                    return true;
                }
                else {
                    this.router.navigate(['/page-not-found']);
                }
            });
    }
}