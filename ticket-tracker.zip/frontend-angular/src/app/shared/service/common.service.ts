import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { UserModel, TicketModel, UserDropDownModel, JwtResponse, AuthLoginInfo } from '../../app.model';
import { BehaviorSubject, Observable } from 'rxjs';
import { TokenStorageService } from './token-storage.service'

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class CommonService {
    serviceUrl: string = environment.api;
    ticketApi: string = '';
    userInfo: JwtResponse;
    userList: UserDropDownModel[] = [];
    isLoading: boolean = false;
    isDisable: boolean = false;
    ticketId: string;

    dataChange: BehaviorSubject<TicketModel[]> = new BehaviorSubject<TicketModel[]>([]);
    // Temporarily stores data from dialogs
    dialogData: TicketModel;
    constructor(private http: HttpClient,private tokenService: TokenStorageService) { }
    isAuthenticated() {
        const promise = new Promise((resolve, reject) => {
            resolve(this.tokenService.getToken() ? true : false)
        });
        return promise;
    }
    isAdmin() {
        const promise = new Promise((resolve, reject) => {
            const role = this.tokenService.getAuthorities();
            resolve(role && role == 'ADMIN' ? true : false)
        });
        return promise;
    }
    attemptAuth(credentials: AuthLoginInfo): Observable<JwtResponse> {
        return this.http.post<JwtResponse>(`${this.serviceUrl}login`, credentials, httpOptions);
    }
    getAPI(url: string) {
        return this.http.get(`${this.serviceUrl}${url}`);
    }
    postAPI(url: string, payLoad: any) {
        return this.http.post(`${this.serviceUrl}${url}`, payLoad);
    }
    putAPI(url: string, id: string, payLoad: any) {
        return this.http.put(`${this.serviceUrl}${url}/${id}`, payLoad);
    }
    deleteAPI(url: string, id: string) {
        return this.http.delete(`${this.serviceUrl}${url}/${id}`);
    }
    get data(): TicketModel[] {
        return this.dataChange.value;
    }

    getDialogData() {
        return this.dialogData;
    }

    getAllTickets(url: string) {
        return this.http.get<TicketModel[]>(url);
    }

    addIssue(issue: TicketModel): void {
        this.dialogData = issue;
    }

    updateIssue(issue: TicketModel): void {
        this.dialogData = issue;
    }

    deleteIssue(id: string): void {
        this.ticketId = id;
    }
}