import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-page-not-found',
    template: '<h1 style="text-align:center">Page Not Found</h1><h4 style="text-align:center">Please Contact Admin</h4>'
})
export class PageNotFoundComponent { }

