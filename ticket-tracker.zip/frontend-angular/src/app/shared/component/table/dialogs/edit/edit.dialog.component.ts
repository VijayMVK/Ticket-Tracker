import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Component, Inject } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { CommonService } from '../../../../service/common.service';
import { TicketModel, DropDownModel, UserDropDownModel } from '../../../../../app.model';

@Component({
  selector: 'app-baza.dialog',
  templateUrl: '../../dialogs/edit/edit.dialog.html',
  styleUrls: ['../../dialogs/edit/edit.dialog.css']
})
export class EditDialogComponent {

  constructor(public dialogRef: MatDialogRef<EditDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, public commonService: CommonService) { }

  formControl = new FormControl('', [
    Validators.required
    // Validators.email,
  ]);

  getErrorMessage() {
    return this.formControl.hasError('required') ? 'Required field' :
      this.formControl.hasError('email') ? 'Not a valid email' :
        '';
  }
  users: UserDropDownModel[] = this.commonService.userList;

  statusList: DropDownModel[] = [
    { code: 'Open', value: 'open' },
    { code: 'Closed', value: 'closed' },
    { code: 'Pending', value: 'pending' },
    { code: 'Resolved', value: 'resolved' },
  ];

  priorityList: DropDownModel[] = [
    { code: 'Low', value: 'low' },
    { code: 'Medium', value: 'medium' },
    { code: 'High', value: 'high' },
    { code: 'Critical', value: 'critical' },
  ];

  submit() {
    // emppty stuff
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  stopEdit(): void {
    this.data.assignedName = this.users.find(x => x.userId == this.data.assignedId).userName;
    this.data.comments = this.data.comments ? this.data.comments : '';
    this.data.updatedBy = this.commonService.userInfo.userName;
    this.data.updatedDate = new Date().toISOString();
    this.commonService.updateIssue(this.data);
  }
}
