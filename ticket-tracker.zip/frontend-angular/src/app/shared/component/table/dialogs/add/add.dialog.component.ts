import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Component, Inject } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { CommonService } from '../../../../service/common.service';
import { TicketModel, DropDownModel, UserDropDownModel } from '../../../../../app.model';
@Component({
  selector: 'app-add.dialog',
  templateUrl: '../../dialogs/add/add.dialog.html',
  styleUrls: ['../../dialogs/add/add.dialog.css']
})

export class AddDialogComponent {
  constructor(public dialogRef: MatDialogRef<AddDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: TicketModel,
    public commonService: CommonService) { }

  formControl = new FormControl('', [
    Validators.required
  ]);

  statusList: DropDownModel[] = [
    { code: 'Open', value: 'open' },
    { code: 'Closed', value: 'closed' },
    { code: 'Pending', value: 'pending' },
    { code: 'Resolved', value: 'resolved' },
  ];

  priorityList: DropDownModel[] = [
    { code: 'Low', value: 'low' },
    { code: 'Medium', value: 'medium' },
    { code: 'High', value: 'high' },
    { code: 'Critical', value: 'critical' },
  ];
  users: UserDropDownModel[] = this.commonService.userList;

  getErrorMessage() {
    return this.formControl.hasError('required') ? 'Required field' :
      this.formControl.hasError('email') ? 'Not a valid email' :
        '';
  }

  submit() {
    // emppty stuff
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  public confirmAdd(): void {
    this.data.assignedName = this.users.find(x => x.userId == this.data.assignedId).userName;
    this.data.createdBy = this.commonService.userInfo.userName;
    this.data.comments = this.data.comments ? this.data.comments : '';
    this.data.updatedBy = this.commonService.userInfo.userName;
    this.data.updatedDate = new Date().toISOString();
    this.data.createdDate = new Date().toISOString();
    this.commonService.addIssue(this.data);
  }
}
