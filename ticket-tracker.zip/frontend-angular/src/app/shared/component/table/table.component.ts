import { Component, ElementRef, OnInit, ViewChild, Input } from '@angular/core';
import { CommonService } from '../../service/common.service';
import { TokenStorageService } from '../../service/token-storage.service';
import { InputModel, TicketModel } from '../../../app.model';
import { HttpClient } from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatSnackBar } from '@angular/material';
import { DataSource } from '@angular/cdk/collections';
import { AddDialogComponent } from './dialogs/add/add.dialog.component';
import { EditDialogComponent } from './dialogs/edit/edit.dialog.component';
import { DeleteDialogComponent } from './dialogs/delete/delete.dialog.component';
import { BehaviorSubject, fromEvent, merge, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {
  displayedColumns = ['ticketId', 'title', 'description', 'assignedName', 'comments', 'status', 'priority', 'createdBy', 'createdDate', 'actions'];
  exampleDatabase: CommonService | null;
  dataSource: TableSource | null;
  isAdmin: boolean = false;
  show: boolean = false;
  inputs: InputModel;
  index: number;
  id: string;

  constructor(public httpClient: HttpClient, public tokenService: TokenStorageService,
    public dialogService: MatDialog, public snackBar: MatSnackBar,
    public commonService: CommonService) { }

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('filter') filter: ElementRef;

  ngOnInit() {
    this.isAdmin = this.commonService.userInfo && this.commonService.userInfo.role == 'ADMIN' ? true : false
    this.loadData();
    if(!this.commonService.userList || !this.commonService.userList.length) {
      this.getUsers();
    }
  }

  reload() {
    this.loadData();
  }
  getUsers() {
    this.commonService.userList = [];
    this.commonService.isLoading = true;
    this.commonService.getAPI('getUsers').subscribe(
      (data: any) => {
        this.commonService.userList = data;
        this.commonService.isLoading = false;
      },
      error => {
        this.commonService.isLoading = false;
      }
    );
  }

  openAddDialog() {
    const dialogRef = this.dialogService.open(AddDialogComponent, {
      data: {}
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 1) {
        this.commonService.isLoading = true;
        this.commonService.postAPI('tickets', this.commonService.getDialogData()).subscribe(
          (data: any) => {
            this.loadData();
            this.snackBar.open(data.msg, 'OK', {
              duration: 10000,
            });
            this.commonService.isLoading = false;
          },
          error => {
            this.snackBar.open(error.msg, 'OK', {
              duration: 10000,
            });
            this.commonService.isLoading = false;
          }
        );
      }
    });
  }

  startEdit(record: TicketModel, i: number) {
    this.id = record.ticketId;
    // index row is used just for debugging proposes and can be removed
    this.index = i;
    console.log(this.index);
    const dialogRef = this.dialogService.open(EditDialogComponent, {
      data: record
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === 1) {
        this.commonService.isLoading = true;
        this.commonService.putAPI('tickets', this.commonService.getDialogData().ticketId, this.commonService.getDialogData()).subscribe(
          (data: any) => {
            this.loadData();
            this.snackBar.open(data.msg, 'OK', {
              duration: 10000,
            });
            this.commonService.isLoading = false;
          },
          error => {
            this.snackBar.open(error.msg, 'OK', {
              duration: 10000,
            });
            this.commonService.isLoading = false;
          }
        );
      }
    });
  }

  deleteItem(record: TicketModel, i: number) {
    this.index = i;
    this.id = record.ticketId;
    const dialogRef = this.dialogService.open(DeleteDialogComponent, {
      data: record
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === 1) {
        this.commonService.isLoading = true;
        this.commonService.deleteAPI('tickets', this.commonService.ticketId).subscribe(
          (data: any) => {
            this.loadData();
            this.snackBar.open(data.msg, 'OK', {
              duration: 10000,
            });
            this.commonService.isLoading = false;
          },
          error => {
            this.snackBar.open(error.msg, 'OK', {
              duration: 10000,
            });
            this.commonService.isLoading = false;
          }
        );
      }
    });
  }

  public loadData() {
    this.exampleDatabase = new CommonService(this.httpClient,this.tokenService);
    this.inputs = { isDisable: this.commonService.isDisable, apiUrl: this.commonService.ticketApi };
    this.dataSource = new TableSource(this.exampleDatabase, this.paginator, this.sort, this.inputs, this.show);
    fromEvent(this.filter.nativeElement, 'keyup')
      .subscribe(() => {
        if (!this.dataSource) {
          return;
        }
        this.dataSource.filter = this.filter.nativeElement.value;
      });
  }
}

export class TableSource extends DataSource<TicketModel> {
  _filterChange = new BehaviorSubject('');
  get filter(): string {
    return this._filterChange.value;
  }

  set filter(filter: string) {
    this._filterChange.next(filter);
  }

  filteredData: TicketModel[] = [];
  renderedData: TicketModel[] = [];

  constructor(public _exampleDatabase: CommonService,
    public _paginator: MatPaginator,
    public _sort: MatSort, public inputs: InputModel, public show: boolean) {
    super();
    // Reset to the first page when the user changes the filter.
    this._filterChange.subscribe(() => this._paginator.pageIndex = 0);
  }

  /** Connect function called by the table to retrieve one stream containing the data to render. */
  connect(): Observable<TicketModel[]> {
    // Listen for any changes in the base data, sorting, filtering, or pagination
    const displayDataChanges = [
      this._exampleDatabase.dataChange,
      this._sort.sortChange,
      this._filterChange,
      this._paginator.page
    ];
    this.show = true;
    this._exampleDatabase.getAllTickets(`${this._exampleDatabase.serviceUrl}${this.inputs.apiUrl}`).subscribe(data => {
      this.show = false;
      this._exampleDatabase.dataChange.next(data);
    }, (error: any) => {
      this.show = false;
      console.log(error.name + ' ' + error.message);
    });
    return merge(...displayDataChanges).pipe(map(() => {
      // Filter data
      this.filteredData = this._exampleDatabase.data.slice().filter((ticket: TicketModel) => {
        if (ticket) {
          const searchStr = (ticket.ticketId +ticket.title + ticket.description + ticket.assignedId + ticket.assignedName + ticket.status + ticket.priority + ticket.comments + ticket.createdBy + ticket.updatedBy + ticket.createdDate + ticket.updatedDate).toLowerCase();
          return searchStr.indexOf(this.filter.toLowerCase()) !== -1;
        }
      });
      // Sort filtered data
      const sortedData = this.sortData(this.filteredData.slice());
      // Grab the page's slice of the filtered sorted data.
      const startIndex = this._paginator.pageIndex * this._paginator.pageSize;
      this.renderedData = sortedData.splice(startIndex, this._paginator.pageSize);
      return this.renderedData;
    }
    ));
  }

  disconnect() { }

  /** Returns a sorted copy of the database data. */
  sortData(data: TicketModel[]): TicketModel[] {
    if (!this._sort.active || this._sort.direction === '') {
      return data;
    }

    return data.sort((a, b) => {
      let propertyA: number | string = '';
      let propertyB: number | string = '';
      switch (this._sort.active) {
        case 'title': [propertyA, propertyB] = [a.title, b.title]; break;
        case 'description': [propertyA, propertyB] = [a.description, b.description]; break;
        case 'assignedId': [propertyA, propertyB] = [a.assignedId, b.assignedId]; break;
        case 'assignedName': [propertyA, propertyB] = [a.assignedName, b.assignedName]; break;
        case 'status': [propertyA, propertyB] = [a.status, b.status]; break;
        case 'priority': [propertyA, propertyB] = [a.priority, b.priority]; break;
        case 'comments': [propertyA, propertyB] = [a.comments, b.comments]; break;
        case 'createdBy': [propertyA, propertyB] = [a.createdBy, b.createdBy]; break;
        case 'updatedBy': [propertyA, propertyB] = [a.updatedBy, b.updatedBy]; break;
        case 'createdDate': [propertyA, propertyB] = [a.createdDate, b.createdDate]; break;
        case 'updatedDate': [propertyA, propertyB] = [a.updatedDate, b.updatedDate]; break;
      }

      const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
      const valueB = isNaN(+propertyB) ? propertyB : +propertyB;

      return (valueA < valueB ? -1 : 1) * (this._sort.direction === 'asc' ? 1 : -1);
    });
  }
}
