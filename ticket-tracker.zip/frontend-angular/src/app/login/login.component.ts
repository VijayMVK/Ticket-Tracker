import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material';
import { CommonService } from '../shared/service/common.service';
import { Router } from '@angular/router';
import { TokenStorageService } from '../shared/service/token-storage.service';
import { AuthLoginInfo } from '../app.model';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  form: any = {};
  isLoggedIn = false;
  isLoginFailed = false;
  errorMessage = '';
  roles: string = ''
  private loginInfo: AuthLoginInfo;

  constructor(private commonService: CommonService, private tokenStorage: TokenStorageService, private router: Router, private snackBar: MatSnackBar) { }

  ngOnInit() {
    this.commonService.ticketApi = '';
    this.commonService.userInfo = undefined;
    this.commonService.userList = [];
    this.commonService.ticketId = '';
    this.tokenStorage.signOut();
  }

  onSubmit() {
    this.loginInfo = new AuthLoginInfo(
      this.form.username,
      this.form.password);
    this.commonService.isLoading = true;
    this.commonService.attemptAuth(this.loginInfo).subscribe(
      data => {
        this.commonService.isLoading = false;
        this.tokenStorage.saveToken(data.accessToken);
        this.tokenStorage.saveUsername(data.userName);
        this.tokenStorage.saveUserId(data.userId);
        this.tokenStorage.saveAuthorities(data.role);

        this.isLoginFailed = false;
        this.isLoggedIn = true;
        this.commonService.userInfo = data;
        this.roles = this.tokenStorage.getAuthorities();
        this.snackBar.open('Login Successful', 'OK', {
          duration: 10000,
        });
        this.router.navigate(['/dashboard']);
      },
      error => {
        console.log(error);
        this.commonService.isLoading = false;
        this.errorMessage = error.error.message;
        this.isLoginFailed = true;
      }
    );

    // this.commonService.isLoading = true;
    // const payload = { 'username': this.form.username, 'password': this.form.password }
    // this.commonService.postAPI('login', payload).subscribe(
    //   (data: any) => {
    //     this.commonService.isLoading = false;
    //     if (data.length) {
    //       this.isLoginFailed = false;
    //       this.snackBar.open('Login Successful', 'OK', {
    //         duration: 10000,
    //       });
    //       this.commonService.userInfo = data[0];
    //       this.router.navigate(['/dashboard']);
    //     } else {
    //       this.isLoginFailed = true;
    //       this.errorMessage = 'Invalid User Name / Password';
    //     }
    //   },
    //   error => {
    //     this.commonService.isLoading = false;
    //     this.errorMessage = error.error.message;
    //     this.isLoginFailed = true;
    //   }
    // );
  }
}
