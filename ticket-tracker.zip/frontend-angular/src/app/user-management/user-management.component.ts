import { Component, OnInit } from '@angular/core';
import { CommonService } from '../shared/service/common.service';
import { TicketModel } from '../app.model';

@Component({
  selector: 'app-user-management',
  templateUrl: './user-management.component.html',
  styleUrls: ['./user-management.component.css']
})
export class UserManagementComponent implements OnInit {
  dataSource;
  tickektList: TicketModel[] = [];
  displayedColumns: string[] = ['userId', 'userName', 'created', 'assigned'];
  constructor(public commonService: CommonService) { }
  ngOnInit() {
    if (this.commonService.userList && this.commonService.userList.length) {
      this.dataSource = this.commonService.userList;
      this.getTickets();
    }
    else {
      this.getUsers();
    }
  }
  getUsers() {
    this.commonService.userList = [];
    this.commonService.isLoading = true;
    this.commonService.getAPI('getUsers').subscribe(
      (data: any) => {
        this.commonService.userList = data;
        this.dataSource = this.commonService.userList;
        this.commonService.isLoading = false;
        this.getTickets();
      },
      error => {
        this.commonService.isLoading = false;
      }
    );
  }
  getTickets() {
    this.commonService.isLoading = true;
    this.commonService.getAllTickets(`${this.commonService.serviceUrl}tickets`).subscribe(
      (data: TicketModel[]) => {
        this.tickektList = data;
        this.commonService.isLoading = false;
      },
      error => {
        this.commonService.isLoading = false;
      }
    );
  }
  createdCount(name: string): number {
    return this.tickektList.filter(x => x.createdBy == name).length;
  }
  assignedCount(id: string): number {
    return this.tickektList.filter(x => x.assignedId == id).length;
  }

}

